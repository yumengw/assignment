


sampleReadsR = function(reads,pos){
  ## Assumes reads are sorted !!
  mp = max(pos)
  sline = integer(mp) 
  for (i in 1:length(reads)) {
    if (reads[i]>mp){
      break
    }
    sline[reads[i]] = sline[reads[i]] + 1
    if (i%%100000 == 0) {
      cat('.')
    }
  }
  reads_line = sline[pos]
  return(reads_line)
}

sampleReads = function(reads,pos){
  mp = max(pos)
  sline = integer(mp) 
  res = .C("sampleLine",PACKAGE = "GCcorrect", sline = as.integer(sline),reads = as.integer(reads),maxpos = as.integer(mp),readslen = as.integer(length(reads)))
  #res$sline counts reads at all(!) positions. Need to subset only requested positions
  return(res$sline[pos])
}


findPileUps = function(dat,windowSize,blockSize = 4000) {
  # Not Finished
  qs = quantile(dat$for1K,c(0.99,0.95,0.5))/1000
  maxPileThresh = ceiling(windowSize*(qs[3]+qs[2]*5))
  minPileThresh = floor(windowSize*qs[1])
  # Run twice through the data - first is to get statistics, second is to decide on cutoff
  cat(maxPileThresh,minPileThresh)
  histog = numeric(maxPileThresh+1-minPileThresh)
  lastpos = 0
  cnt=0
  lastLoc = 0
  res = numeric(max(dat$forw))
  cat(sprintf('Use %g blocks\n',ceiling(length(dat$forw)/blockSize)))
  for (b in 1:ceiling(length(dat$forw)/blockSize)) {
    cat('.')
    datRange = c(max(1,1+(b-1)*blockSize-maxPileThresh),min((b)*blockSize-1+maxPileThresh,length(dat$forw)))
    chromRange = c(lastLoc+1,dat$forw[min(datRange[2]-maxPileThresh+1,length(dat$forw))])
    lastLoc = chromRange[2]
    cat(c(datRange[1],datRange[2],chromRange,dat$forw[c(datRange[1],datRange[2])]))
    res[chromRange[1]:chromRange[2]] = shortReadDensity(dat$forw[datRange[1]:datRange[2]],c(chromRange[1],chromRange[2]),windowSize)
  }
  cat('\n')
  res[res>maxPileThresh] = maxPileThresh+1
  return(list(res, c(minPileThresh,maxPileThresh)))
}

findLongZeros  = function(line,thresh) {
  cline = cumsum(c(FALSE,line==0))
  zero_begs = which((cline==shift(cline,-1))&(cline!=shift(cline,1)))
  zero_ends = which((cline==shift(cline,1))&(cline!=shift(cline,-1)))
  if (line[1]==0){
    zero_begs = c(1,zero_begs)
  }
  if (line[length(line)]==0){
    zero_ends = c(zero_ends,length(line)+1)
  } 
  zerolens = zero_ends- zero_begs
  return(rbind(zero_begs,zero_ends)[,zerolens>thresh])
}


shortReadDensity = function(reads,workRange,winSize) {
  nexti = -Inf
  winCnts = (workRange[1]: workRange[2] ) *0
  for(i in workRange[1]:workRange[2]) {
    if( i > nexti) {
      winCnts[i-workRange[1]+1] = sum(is.element(reads,1:winSize+i-1))
      if (winCnts[i-workRange[1]+1] == 0) {
        nexti = reads[which(reads>i)[1]] - winSize -1
      } else {
        nexti = -Inf
      }
    }
  }
  return (winCnts)
}


filterSampleReads = function(reads,locations, lenrange) {
  # Count only filtered reads in singleLocSamp locations
  filtReads = (abs(reads[,2]) >= lenrange[1]) & (abs(reads[,2]) <= lenrange[2])
  return(sampleReads(reads[filtReads,1],locations))
}

sampleChrom = function(chr,dat,n=10000000,margin = 1000,len_range = c(), memoryopt = TRUE,useSamp = c()) {

  sampSt = list()
  chrLen =  length(chr$isrep)

  # useSamp is a vector the length of isrep or isgc that gives FALSE where you should not sample
  # This is good for peaks, signal, null-areas or any other areas we want to avoid

  # Set sampled locations
  if (is.logical(useSamp) && !(memoryopt)){
    toSamp = which(useSamp & (!chr$isrep))
  } else if (is.null(useSamp) || memoryopt) {
    toSamp = chrLen
  } else {
    toSamp = useSamp
  }

  tmpSamp = sample(toSamp,size = n)
  tmpSamp = tmpSamp[(tmpSamp > margin)  & (tmpSamp < (chrLen-margin))] 

  if (memoryopt){
    # It is more efficient to use sample(n) rather than sample(1:n)
    # If efficiancy is prefered, we first sample and then remove
    # This leads to variations in the sample size
    tmpSamp = tmpSamp[(useSamp & (!chr$isrep))[tmpSamp]]
  }
  sampSt$singleLocSamp = sort(tmpSamp)
  sampSt$len_range = len_range
  if (is.null(len_range)){
      # Tabulate Reads by sample
    sampSt$forsamped = sampleReads(dat$forw[,1],sampSt$singleLocSamp)
    sampSt$revsamped = sampleReads(dat$reve[,1],sampSt$singleLocSamp)
  } else {
    sampSt$forsamped = filterSampleReads(dat$forw,sampSt$singleLocSamp,len_range)
    sampSt$revsamped = filterSampleReads(dat$reve,sampSt$singleLocSamp,len_range)
  }
    
  cat(sprintf('Sample of %g with %g forward, %g reverse reads\n', length(sampSt$singleLocSamp),sum(sampSt$forsamped),sum(sampSt$revsamped)))
  return (sampSt)
}

