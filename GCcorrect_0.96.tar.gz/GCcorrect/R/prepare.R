
####################
#
# prepare.R
# Prepares structures representing chromosomes ( bases, gc and mappability)
# And structures representing mapped-read results (forward and reverse strands + lengths) 
#
# Yuval Benjamini (yuvalb@stat.berkeley.edu)
# August 2011
####################

readFastaFile = function(filename) {
  lines = readLines(filename)
  # Remove header if one exists
  if (substr(lines[1],1,1)=='>') {
    lines = lines[-1]
  }
  return(toupper(paste(lines,collapse='')))
}

readRepeats = function(filename) {
  return(strsplit(readFastaFile(filename),'')[[1]] == 'R')
}

readChrom = function(filename) {
  chromChr = strsplit(readFastaFile(filename),'')[[1]]

  chrline = integer(length(chromChr))
  chrline[chromChr=='A'] = 0
  chrline[chromChr=='T'] = 1
  chrline[chromChr=='C'] = 2 
  chrline[chromChr=='G'] = 3
  chrline[chromChr=='N'] = NA
  return(chrline)
}

prepareChrom = function(filename, reference = NULL ,repeats = NULL, savefile = TRUE, clean=FALSE,details = "") {
  # If chrom already prepared - load
  if (file.exists(filename) & (!clean)) {
    load(filename)
  }
  else {
    if(is.character(repeats)){
      isrep = readRepeats(repeats)
    } else if (is.logical(repeats)) {
      isrep = repeats
    }
    if(is.character(reference)){
      chrline = readChrom(reference)
    } else if (is.numeric(reference)) {
      stopifnot(sum(reference>3,na.rm = TRUE) == 0)
      chrline = reference
    }
  
    isgc = chrline>=2
    chromStruct = list(isgc =isgc, isrep = isrep , chrline = chrline, details = details)

   
    chromStruct[['map10K']] = meanLine(chromStruct$isrep,100)
    chromStruct[['gc10K']] = meanLine(chromStruct$isgc,100)
    if (savefile){
      save(chromStruct,file = filename)
    }
  } 
  return(chromStruct)
}

meanLine = function(origline, binsize){
  binline= numeric(ceiling(length(origline)/binsize))
  origline[is.na(origline)] = 0 # Perhaps need to better deal with nas

  # The C functions only sum
  if (is.logical(binline)) {
    res = .C("sumLine", PACKAGE = "GCcorrect", bline = as.integer(binline), as.integer(origline), as.integer(length(origline)),as.integer(binsize))
  } else {
    res = .C("sumLineDouble",  PACKAGE = "GCcorrect", bline = as.double(binline), as.double(origline), as.integer(length(origline)),as.integer(binsize))
  }
  return(res$bline/binsize)

}

meanLineR = function(origline,k,norm = TRUE){
#  stopifnot(na)
  mapa = ceiling(length(origline)/k)
  for (i in 1:length(mapa)){
    if (norm) {
      mapa[i] = mean(origline[(1+k*(i-1)):min(k*i,length(origline))])
    }
    else {
      mapa[i] = mean(origline[(1+k*(i-1)):min(k*i,length(origline))])
    }
  }
  return(mapa)
}

prepareReads = function(forward,reverse,chr_len=-1,chr_name=chr_name,readlen, ref_name = ""){
  # forward and reverse are tables (2 columns) of locations and lengths (when available)
  # of fragments of a single chromosome, mapped to forward or reverse strand

  # chr_len when supplied will pad binned lines with zeros accordingly
  
  # Name of reference, chromosome, and the read length are only for book-keeping
  # locations are counted from 1
  dat = list(forw = forward,reve = reverse, chr_len = chr_len, chr_name= chr_name ,readlen = readlen,ref_name= ref_name)
  dat$for10K = binReads(dat$forw[,1],100,chr_len)
  dat$rev10K = binReads(dat$reve[,1],100,chr_len)
  
  return (dat)
}


binReads = function(reads, binsize,chr_len = -1){
  if (chr_len < 0) {
    chr_len = max(reads)
  }
  len = ceiling(chr_len/binsize)
  bline = numeric(len)
  res = .C("binReads",PACKAGE = "GCcorrect",binline = as.integer(bline), reads = as.integer(reads), fieldsize = as.integer(length(reads)),binsize= as.integer(binsize))
  return (res$binline)
}



genOverlapLine = function(oline,shifts,avg = TRUE) {
  # This function adds shifted lines according to the shift list.
  # When 'avg = T', sum is divided by the number of shifts
  # onTheWay is a list of shifts for which a temporary sum is saved
  # we use the convention: fname%f where %f is current shift
  oline = as.integer(oline)
  nas = which(is.na(oline))
  oline[nas] = -1
  nline = integer(length(oline))
  # Check if these are consecutive spots to average:
  if (all(shifts == 0:(length(shifts)-1))){
    res = .C("runAverage", PACKAGE = "GCcorrect", origline = as.integer(oline), nline = as.integer(nline), linelen = as.integer(length(oline)),
      winsize = as.integer(length(shifts)))
  } else { 
    res = .C("genOverlapLine", PACKAGE = "GCcorrect", origline = as.integer(oline), nline = as.integer(nline), linelen = as.integer(length(oline)),
      shifts = as.integer(shifts), nshifts = as.integer(length(shifts)))
  }
  res$nline[res$nline<0] = NA
  if (avg == FALSE){
    return (res$nline)
  } else {
    avgconst = length(shifts)
    return (res$nline/avgconst)
  }
}

genOverlapLineReal = function(oline,shifts,avg = TRUE) {
  # This function adds shifted lines according to the shift list.
  # When 'avg = T', sum is divided by the number of shifts
  # onTheWay is a list of shifts for which a temporary sum is saved
  # we use the convention: fname%f where %f is current shift
  nas = which(is.na(oline))
  oline[nas] = -1
  nline = integer(length(oline))
  res = .C("genOverlapLineReal", PACKAGE = "GCcorrect", origline = as.numeric(oline), nline = as.numeric(nline), linelen = as.integer(length(oline)), shifts = as.integer(shifts),
    nshifts = as.integer(length(shifts)))
  if (avg == FALSE){
    avgconst = 1
  } else {
    avgconst = length(shifts)
  }
  res$nline[res$nline<0] = NA
  return (res$nline/avgconst)
}


prepareGCChrom = function(chr,winsize,filename,clean=FALSE, savefile = TRUE) {
  # If chrom already prepared - load
  if (file.exists(sprintf('%s_%s',filename,winsize-1)) & (!clean)) {
    load(sprintf('%s_%s',filename,winsize-1))
  }
  else {
    line = as.integer(genOverlapLine(chr$isgc,0:(winsize-1),avg=FALSE))
    if (savefile) {
      save(line,file = sprintf('%s_%s',filename,winsize-1))
    }
  }
  return(line)
}

prepareGCChromR = function(chr,winsize,filename,clean=FALSE, savefile = TRUE) {
  # If chrom already prepared - load
  if (file.exists(sprintf('%s_%s',filename,winsize-1)) & (!clean)) {
    load(sprintf('%s_%s',filename,winsize-1))
  }
  else {
    line = genOverlapLineReal(chr$isgc,0:(winsize-1),avg=FALSE)
    if (savefile) {
      save(line,file = sprintf('%s_%s',filename,winsize-1))
    }
  }
  return(line)
}
