

plotCondMean = function(cMean,ci = FALSE,newplot = TRUE,normRange = 0,meanLine=FALSE,lt = 1,...){
  if (cMean$norm) {
    ci_corr= cMean$tot_mean
    dat_mean = 1
    ylabel = 'Normalized Rate'
  }  else {
    ci_corr = 1
    dat_mean = cMean$tot_mean
    ylabel = 'Rate'
  }
  xvals = as.numeric(names(cMean$tab_means))
  if (normRange > 0){
    xvals = xvals/normRange
  }
  if (newplot) {
    plot(xvals,cMean$tab_means,col = 0,main = sprintf('TV = %g',cMean[[3]]) ,ylim = c(0,max(cMean$tab_means)),xlab = 'GC', ylab=ylabel)
  }
  lines(xvals,cMean$tab_means,...)
  if (meanLine){
    abline(dat_mean,0,lt=2)
  }
  if (ci){
    tot_mean = cMean$tot_mean
    segments(xvals,cMean$tab_means-(sqrt(cMean$tab_means)/sqrt(cMean$cts*ci_corr)),
             xvals,cMean$tab_means+(sqrt(cMean$tab_means)/sqrt(cMean$cts*ci_corr)),...)
  }
}

gcPlotChrom = function(datstruct,yl = c(0,80),mapthresh = 0.92,...) {
  ismap = datstruct$map > mapthresh
  xl = quantile(datstruct$gc[ismap],c(0.001,0.999),na.rm=TRUE)
  plot(datstruct$gc[ismap],datstruct$cnt[ismap]+rnorm(sum(ismap),0,0.2),pch=20,ylim = yl,xlim = xl,xlab = 'GC', ylab = 'Count',col = rgb(0,0,0,alpha=0.2))  
}

basicPlots = function(dat,types = c(),align = TRUE,binsize='10K'){
  # First: count plots (basic mappings):
  #  A. Count density curves, per binsize(100bp,1K,10K): total, forward, reverse
  #  B. Length density curves - total, forward, reverse
  #  C. Counts by genome location (1K/10K depends on chrom length)
  #  D. Correlation between strand (10K)

  if ((length(types) == 4) && (align == TRUE )) {
    mat = t(matrix(c(3,3,3,4,4,4,1,2,5),nrow=3))
    layout(mat)
    align = FALSE
  }

  forbin = sprintf('for%s',binsize)
  revbin = sprintf('rev%s',binsize)

  limfor = quantile(dat[[forbin]],0.999)
  limrev = quantile(dat[[revbin]],0.999)

  if(is.element(1,types)){
    if (align) {
      par(mfcol = c(1,1))
    }
    par(mar = c(4,4,3,3))
    dfor = density(dat[[forbin]],to = limfor)
    drev = density(dat[[revbin]],to = limrev)
    if(max(dfor$y,na.rm=TRUE)>max(drev$y,na.rm =TRUE)){
       dplot = dfor
    } else {
      dplot = drev
    }
    
    plot(dplot,col = 0,main = sprintf('%s Bins: Read Density',binsize))
    lines(dfor,col=1,lw=2)
    lines(drev,col=2,lw=2)
  }
  if(is.element(2,types)){
    if (align) {
      par(mfcol = c(1,1))
    }
    par(mar = c(4,4,3,3))
    plot(density(abs(dat$reve[,2]),from=1,to = quantile(abs(dat$reve[,2]),0.999)),col=0,main= 'Fragment Length Density')
    lines(density(dat$forw[,2],from=1,to = quantile(dat$forw[,2],0.999)),col=1,lw=2)
    lines(density(abs(dat$reve[,2]),from=1,to = quantile(abs(dat$reve[,2]),0.999)),col=2,lw=2)
  }
  
  if(is.element(3,types)){
    if(align){
      par(mfcol = c(2,1))
    }
    par(mar = c(2,2,2,2))
    plot(dat[[forbin]],xlab = 'Genome Location', main = sprintf('Read counts in %s bins, Forward strand',binsize), cex = 0.3,pch = 20,ylim = c(0,limfor),col=rgb(0,0,0,0.3))
    outli = which(dat[[forbin]]>limfor)
    points(outli,rep(limfor,length(outli)), col = 4, cex=0.6)
    plot(dat[[revbin]],xlab = 'Genome Location', main = sprintf('Read counts in %s bins, Reverse strand',binsize), cex = 0.3,pch = 20,ylim = c(0,limrev),col=rgb(0,0,0,0.3))
    outli = which(dat[[revbin]]>limrev)
    points(outli,rep(limrev,length(outli)), col = 4, cex=0.6)
  }
  
  if(is.element(4,types)){
    if(align){
      par(mfcol = c(1,1))
    }
    par(mar = c(4,4,3,3))
    outlie = c(which(dat[[revbin]]>limrev),which(dat[[forbin]]>limfor))
    plot(dat[[forbin]][-outlie],dat[[revbin]][-outlie],cex = 0.5,col=rgb(0,0,0,0.3),pch=20,xlab = 'Forward counts',ylab = 'Reverse counts',main ='Strand counts')
    abline(0,1,col=4)
  }
}


compDataRefPlots = function(chr ,dat,types,binsize = '10K',align=TRUE) {

  if ((length(types) >= 3) && (align == TRUE )) {
    mat = matrix(c(1,2,3,1,2,3,1,2,3,0,4,5,0,4,5),nrow=3)
    layout(mat)
    align = FALSE
  }

  forbin = sprintf('for%s',binsize)
  revbin = sprintf('rev%s',binsize)
  mapbin = sprintf('map%s',binsize)
  gcbin = sprintf('gc%s',binsize)

  limboth = quantile(dat[[forbin]],0.997)+quantile(dat[[revbin]],0.997) + 20
  outli = which(dat[[forbin]]+dat[[revbin]]>limboth)
  #  A. Three chromosome-wise plots
  if(is.element(1,types)){
    if (align) {
      par(mfcol = c(3,1))
    }
    par(mar = c(2,2,2,2))

    plot(dat[[forbin]]+dat[[revbin]],xlab = 'Genome Location', main = sprintf('Read counts in %s bins',binsize), cex = 0.3,pch = 20,ylim = c(0,limboth))
    
    points(outli,rep(limboth,length(outli)), col = 4, cex=0.6)
    plot(1-chr[[mapbin]], main = sprintf('Mappability %s',binsize) , cex = 0.3,pch = 20)
    plot(chr[[gcbin]], main = sprintf('GC %s Bins',binsize), cex = 0.3,pch = 20)
  }

  #  B. Counts by Map (on bins)
  if(is.element(2,types)){
    if (align) {
      par(mfcol = c(1,1))
    }
    par(mar = c(4,4,3,3))
    maxsizebin = min(c(length(dat[[forbin]]),30000))
    sampbin = setdiff(sample(length(dat[[forbin]]),maxsizebin),outli)
    plot(1-chr[[mapbin]][sampbin],(dat[[forbin]]+dat[[revbin]])[sampbin],pch=20,cex =1,col = rgb(0,0,0,0.2),main = 'Map vs. Counts bins',ylab = 'Counts', xlab = '% Mappable',ylim = c(0,limboth) )
    abline(0,median((dat[[forbin]]+dat[[revbin]])[ chr[[mapbin]][sampbin]>0.99]),col=4,lw=2)
   }

#  C. Unmappable mapped (%)
  if(is.element(3,types)){
    fowardUnmap = mean(chr$isrep[dat$forw[,1]]) # Percentage of forward reads mapped to unmappable positions
    reverseUnmap = mean(chr$isrep[dat$reve[,1]]) # Percentage of reverse reads 

    Unmap = mean(chr$isrep)
    cat(sprintf("Ratio between unmappable bases and unmappable reads rate %g (Forward Strand)\n",Unmap/fowardUnmap))
    cat(sprintf("Ratio between unmappable bases and unmappable reads rate %g (Reverse Strand)\n",Unmap/reverseUnmap))
  }
  #  D. Counts by GC (on bins) - Only highly mappable bins moslty visable
  if (is.element(4,types)){
    if (align) {
      par(mfcol = c(1,1))
    }
    par(mar = c(4,4,3,3))
    map_cutoff = 0.1
    maxsizeb = min(sum(chr[[mapbin]]<map_cutoff),8000)
    sampbinb = setdiff(sample(which(chr[[mapbin]]<map_cutoff),maxsizeb),outli)
    plot(chr[[gcbin]][sampbinb],(dat[[forbin]]+dat[[revbin]])[sampbinb]+rnorm(length(sampbinb),0,0.3),pch=20,cex= 0.6, col =rgb(0,0,0,0.3), main = 'GC effect',ylab = 'Counts', xlab = 'GC',ylim= c(0,limboth) )
    lines(smooth.spline(chr[[gcbin]][sampbinb],(dat[[forbin]]+dat[[revbin]])[sampbinb],spar=1),col=4,lw=2)
  }
      #  E. Find and remove pileups


#  F. Sanity checks that GC , Mapping, Reads fit together,  

}


# Function commented out until I find a consistent support for fields.
plotRateSizes = function(...) {
  warning("Currently not supported")
}

#plotRateSizes = function(ratesmat,sfrom, sto,margin,figs = c(1,2)){
#  if(length(figs) == 2){
#    par(mfcol = c(2,1),mar = c(3,3,3,3))
#  }
#  if(is.element(1,figs)){
#    require('fields')
#
#    image.plot(ratesmat,xlim = c(0,ceiling(sto*0.8)),ylim = c(sfrom-10,sto+10),xlab = "GC in Fragment",
#               ylab = "Fragment Length",main = "Fragment rates by length and GC")
#    for (i in seq(0.2,0.8,0.1)) {
#      abline(0,1/i,lt=2,lw=0.5)
#    }
#  }
#  if(is.element(2,figs)){
#    sizes = seq(sfrom,sto,ceiling((sto-sfrom) /9))
#    colvec =   colvec = c(rgb(0,0,0.2),rgb(0,0,0.6),rgb(0,0,0.9),rgb(0.5,0,0.9), rgb(0.7,0,0.7),rgb(0.9,0,0.4), rgb(0.9,0.2,0.6),rgb(1,0.5,0.6),rgb(1,0.7,0.7))[1:length(sizes)]
#    plot(0,0,col = 0, ylim = c(0,max(ratesmat$z)), xlim = c(0,1),xlab = 'GC',ylab = "Fragment Rate",
#         main = "Single length GC-curves")
#    mc = 2*margin
#    for (i in 1:length(sizes)) {
#      lines((0:sizes[i])/(sizes[i]-mc),ratesmat$z[1:(sizes[i]+1),(sizes[i]+1)],lw=1.5,col = colvec[i])
#    } 
#    legend(0.8,max(ratesmat$z),sizes,title = "Length",lw = 2, col = colvec)
#  }
#}


plotGCLens = function(tvs,dat = c(), col = 2,scale = TRUE,ylim = c(),newplot = TRUE,... ) { 
  if (length(ylim)==0){
    ylim = c(0,max(tvs,na.rm=TRUE))
  }
  if (newplot) {
    plot(0:(length(tvs)-1),tvs,col = 0,xlab = "Window size (not including margin)",  ylim = ylim)
  }
  lines(0:(length(tvs)-1),tvs, col=col,...)
  if (!is.null(dat)){
    qsTV = quantile(dat$forw[which(dat$forw[,2]>0),2],c(0.1,0.5,0.9))
    sc = ylim/50
    rect(ybottom = 0.0, ytop=sc, xleft = 0,xright = qsTV[2],col = col)
    segments(y0 = sc/2, y1 = sc/2, x0 = qsTV[1],x1 = qsTV[3],col = 1, lwd = 2)
    segments(y0 = 0.001, x0 = qsTV[2], y1 = tvs[qsTV[2]],lty = 2,col=col)
  }
}
